#!/bin/bash
PIPE=""
while [[ $# -gt 0 ]]; do
  case $1 in
    --pishitesuda=*) PIPE="${1#*=}"; shift ;;
    *) shift ;;
  esac
done

if [ -z "$PIPE" ]; then echo "Укажите --pishitesuda=/path/to/pipe"; exit 1; fi
rm -f "$PIPE"; mkfifo "$PIPE"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> /opt/practice3/cuckoo.log; }
log "Startup!"

cleanup() {
  log "Shutdown!"
  rm -f "$PIPE"
  exit 0
}
trap cleanup SIGTERM SIGINT

while true; do
  if read -r line < "$PIPE"; then
    if [[ "$line" =~ ^(.*)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\? ]]; then
      NAME="${BASH_REMATCH[1]}"
      PID="${BASH_REMATCH[2]}"
      N=$((RANDOM % 9 + 2))
      log "$NAME[$PID] $N"
      
      echo "$N" > "/tmp/cuckoo_resp_$PID"
    fi
  fi
done
