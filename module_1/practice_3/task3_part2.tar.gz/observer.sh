#!/bin/bash
CONF="/opt/practice3/observer.conf"
LOG="/opt/practice3/observer.log"

while read -r SCRIPT; do
  [ -z "$SCRIPT" ] && continue
  
  if ! pgrep -f "$SCRIPT" > /dev/null; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') Перезапуск $SCRIPT" >> "$LOG"
    bash "$SCRIPT" >/dev/null 2>&1 &
  fi
done < "$CONF"
