#!/bin/bash
SELF_NAME=$(basename "$0")
if [ "$SELF_NAME" = "template_task.sh" ]; then
  echo "я бригадир, сам не работаю"
  exit 0
fi

LOG_FILE="/opt/practice3/report_${SELF_NAME}.log"
echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт запущен" >> "$LOG_FILE"

PIPE="/tmp/cuckoo_pipe"
RESP_PIPE="/tmp/cuckoo_resp_$$"

if [ ! -p "$PIPE" ]; then echo "Канал не найден"; exit 1; fi

mkfifo "$RESP_PIPE"

echo "${SELF_NAME}[$$]: how much time do I have?" > "$PIPE"

read -r N < "$RESP_PIPE"
rm -f "$RESP_PIPE"

sleep "$N"

echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] Скрипт завершился, работал $N секунд." >> "$LOG_FILE"
